import java.util.Scanner;

public class Uni4Exe05 {

    public static void main(String[] args) throws Exception {

        Scanner tec = new Scanner(System.in);

        /*
         * Uni4Exe05.java - Dada uma pergunta, “a cor é azul?”, faça um programa que
         * leia uma variável lógica com a resposta e responda “Sim”, caso a resposta
         * seja true, ou “Não”, caso seja false.
         */

        System.out.println("A cor é azul?");
        boolean resp = tec.nextBoolean();

        if (resp)
            System.out.println("Sim");
        else
            System.out.println("Não");
    
        tec.close();
    }
}
